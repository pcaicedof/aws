import boto3
from utils.constants import aws_access_key_id, aws_secret_access_key, source_bucket, target_bucket
import logging

s3_client = boto3.client('s3',
                         aws_access_key_id=aws_access_key_id,
                         aws_secret_access_key=aws_secret_access_key)

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s | %(name)s'
                           '| %(levelname)s | %(message)s')

def copy_files_to_raw(source_bucket, target_bucket, s3_client):
    objects = s3_client.list_objects_v2(Bucket=source_bucket)['Contents']    
    for obj in objects:
        copy_source = {
            'Bucket': source_bucket,
            'Key': obj['Key']
        }
        print(copy_source)
        target_key = f"raw/{obj['Key']}" if target_bucket else obj['Key']
        s3_client.copy(copy_source, target_bucket, target_key)
        logging.info(f"File {obj['Key']} has been copied")


def main(event, context):
    #print(event)
    logging.info("Process started")
    copy_files_to_raw(source_bucket, target_bucket, s3_client)


