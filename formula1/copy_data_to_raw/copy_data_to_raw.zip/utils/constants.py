source_bucket = 'orbidi-data-sources'
target_bucket = 'orbidi-data-project'
region_name = 'us-east-1'