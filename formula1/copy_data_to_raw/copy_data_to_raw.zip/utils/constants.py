aws_access_key_id = 'AKIAVRUVPVA5Q6FBRG6C'
aws_secret_access_key = '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'
region_name = 'TU_REGION'